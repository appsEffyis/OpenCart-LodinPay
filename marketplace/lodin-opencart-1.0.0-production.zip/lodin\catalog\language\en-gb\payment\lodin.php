<?php
// Heading
$_['heading_title'] = 'Lodin RTP Payment';

// Text
$_['text_title'] = 'Lodin RTP Payment';
$_['text_loading'] = 'Loading...';

// Button
$_['button_confirm'] = 'Confirm Order';

// Error
$_['error_order'] = 'Order not found';
$_['error_payment'] = 'Payment processing error. Please try again.';
