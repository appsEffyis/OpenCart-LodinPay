<?php
namespace Opencart\Catalog\Controller\Extension\Lodin\Payment;

class Lodin extends \Opencart\System\Engine\Controller {
    
    const RTP_API_URL = 'https://api-preprod.lodinpay.com/merchant-service/extensions/pay/rtp';
    
    /**
     * Display payment method in checkout
     */
    public function index(): string {
        $this->load->language('extension/lodin/payment/lodin');
        
        $data['button_confirm'] = $this->language->get('button_confirm');
        $data['text_loading'] = $this->language->get('text_loading');
        $data['language'] = $this->config->get('config_language');
        
        return $this->load->view('extension/lodin/payment/lodin', $data);
    }
    
    /**
     * Confirm payment and generate link
     */
    public function confirm(): void {
        $this->load->language('extension/lodin/payment/lodin');
        
        $json = [];
        
        if (!isset($this->session->data['order_id'])) {
            $json['error'] = $this->language->get('error_order');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }
        
        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        
        if (!$order_info) {
            $json['error'] = $this->language->get('error_order');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }
        
        try {
            $payment_link = $this->generatePaymentLink($order_info);
            
            if ($payment_link) {
                // Update order status to pending
                $this->model_checkout_order->addHistory(
                    $this->session->data['order_id'],
                    $this->config->get('payment_lodin_pending_status_id'),
                    'Awaiting Lodin RTP payment',
                    false
                );
                
                $json['redirect'] = $payment_link;
            } else {
                throw new \Exception('Failed to generate payment link');
            }
            
        } catch (\Exception $e) {
            $this->log->write('LODIN ERROR: ' . $e->getMessage());
            $json['error'] = $this->language->get('error_payment');
        }
        
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    
    /**
     * Generate payment link via Lodin API
     */
    private function generatePaymentLink(array $order_info): ?string {
        $client_id = $this->config->get('payment_lodin_client_id');
        $client_secret = $this->config->get('payment_lodin_client_secret');
        
        if (!$client_id || !$client_secret) {
            throw new \Exception('Lodin configuration missing');
        }
        
        $invoice_id = 'ORDER-' . $order_info['order_id'] . '-' . time();
        $amount = number_format($order_info['total'], 2, '.', '');
        
        // Generate signature
        $timestamp = gmdate('Y-m-d\TH:i:s\Z');
        $payload = $client_id . $timestamp . $amount . $invoice_id;
        $signature = $this->generateSignature($payload, $client_secret);
        
        // Debug logging
        $this->log->write('LODIN DEBUG - Client ID: ' . $client_id);
        $this->log->write('LODIN DEBUG - Timestamp: ' . $timestamp);
        $this->log->write('LODIN DEBUG - Amount: ' . $amount);
        $this->log->write('LODIN DEBUG - Invoice ID: ' . $invoice_id);
        $this->log->write('LODIN DEBUG - Payload: ' . $payload);
        $this->log->write('LODIN DEBUG - Signature: ' . $signature);
        
        // Prepare API request
        $headers = [
            'Content-Type: application/json',
            'X-Client-Id: ' . $client_id,
            'X-Timestamp: ' . $timestamp,
            'X-Signature: ' . $signature,
            'X-Extension-Code: OPENCART',
        ];
        
        $body = [
            'amount' => (float) $amount,
            'invoiceId' => $invoice_id,
            'paymentType' => 'INST',
            'description' => 'OpenCart Order #' . $order_info['order_id'],
        ];
        
        // Make API call
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, self::RTP_API_URL);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $this->log->write('LODIN API Response: ' . $response);
        
        if ($http_code === 200) {
            $data = json_decode($response, true);
            return isset($data['url']) ? $data['url'] : null;
        }
        
        throw new \Exception('API error: ' . $response);
    }
    
    /**
     * Generate HMAC signature
     */
    private function generateSignature(string $payload, string $secret): string {
        $raw_hmac = hash_hmac('sha256', $payload, $secret, true);
        $base64 = base64_encode($raw_hmac);
        $url_safe = strtr($base64, ['+' => '-', '/' => '_']);
        return rtrim($url_safe, '=');
    }
    
    /**
     * Webhook callback handler
     */
    public function callback(): void {
        $this->log->write('LODIN Webhook received');
        
        // Get raw POST data
        $payload = file_get_contents('php://input');
        
        if (empty($payload)) {
            http_response_code(400);
            die('Bad Request');
        }
        
        // Verify signature
        $signature = $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? null;
        
        if (!$this->verifyWebhookSignature($payload, $signature)) {
            http_response_code(401);
            die('Unauthorized');
        }
        
        // Parse webhook data
        $data = json_decode($payload, true);
        
        if (!$data) {
            http_response_code(400);
            die('Invalid JSON');
        }
        
        $this->log->write('LODIN Webhook data: ' . print_r($data, true));
        
        try {
            $this->handleWebhook($data);
            http_response_code(200);
            die('OK');
        } catch (\Exception $e) {
            $this->log->write('LODIN Webhook error: ' . $e->getMessage());
            http_response_code(500);
            die('Internal Server Error');
        }
    }
    
    /**
     * Verify webhook signature
     */
    private function verifyWebhookSignature(string $payload, ?string $received_signature): bool {
        if (!$received_signature) {
            return false;
        }
        
        $client_secret = $this->config->get('payment_lodin_client_secret');
        
        if (!$client_secret) {
            return false;
        }
        
        $expected_signature = $this->generateSignature($payload, $client_secret);
        
        return hash_equals($expected_signature, $received_signature);
    }
    
    /**
     * Handle webhook events
     */
    private function handleWebhook(array $data): void {
        $event_type = $data['eventType'] ?? null;
        $invoice_id = $data['invoiceId'] ?? null;
        
        if (!$event_type || !$invoice_id) {
            throw new \Exception('Missing required fields');
        }
        
        // Extract order ID from invoice ID (ORDER-123-timestamp)
        $parts = explode('-', $invoice_id);
        if (count($parts) < 2) {
            throw new \Exception('Invalid invoice ID format');
        }
        
        $order_id = (int) $parts[1];
        
        $this->load->model('checkout/order');
        
        switch ($event_type) {
            case 'payment.succeeded':
            case 'payment.completed':
                $this->model_checkout_order->addHistory(
                    $order_id,
                    $this->config->get('payment_lodin_completed_status_id'),
                    'Payment received via Lodin RTP. Transaction ID: ' . ($data['transactionId'] ?? 'N/A'),
                    true
                );
                break;
                
            case 'payment.failed':
            case 'payment.declined':
                $this->model_checkout_order->addHistory(
                    $order_id,
                    $this->config->get('payment_lodin_failed_status_id'),
                    'Payment failed: ' . ($data['errorMessage'] ?? 'Unknown error'),
                    false
                );
                break;
        }
    }
}
